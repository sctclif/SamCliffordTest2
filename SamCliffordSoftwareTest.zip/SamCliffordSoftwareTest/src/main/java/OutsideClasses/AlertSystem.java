package OutsideClasses;

public class AlertSystem {
    public static void alertAKeeper(String phone){
        System.out.println("Ringing keeper on "+phone);
    }
    public static void alertADrone(int freq){
        System.out.println("Alerting drone on frequency "+freq);
    }
}